package com.nbvarnado.popularmovies.data.database;


/**
 * Created by Nick Varnado on 3/13/2019.
 */

public class Movie {
}
